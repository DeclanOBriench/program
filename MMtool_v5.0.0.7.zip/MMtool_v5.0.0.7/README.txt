Today we’re diving into one of BIOS utilities: MMTool. So what does MMTool stand for? MMtool stands for Module Management Tool. As one of AMI’s BIOS/UEFI utilities, MMTool allows users to manage firmware file modules within the Aptio ROM image. The utility is particularly useful in the case where modules and/or Option ROMs need to be upgraded after the initial Aptio ROM image has already been built.

With MMTool, users can insert, delete and extract modules or Option ROM images. MMTool can display all the file module information within the Aptio ROM image. Other useful features of MMTool include:

Manages compressed modules
Creates reports of opened firmware image contents
Modifies firmware image without rebuilding ROM image
Supports PEI/DXE modules
Supports command line options
The MMTool utility is supported by the x64, x86 and ARM architectures. If customers require customized, locked version of the MMTool utility, the MMTool utility can be specifically locked to an OEM’s platform. The locked version of the MMTool utility can then be distributed to the OEM’s end users.